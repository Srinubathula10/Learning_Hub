import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import ServicesSection from './components/ServicesSection';
import About from './pages/About';
import Contact from './pages/Contact';
import SignUp from './pages/SignUp';
import UserLogin from './pages/UserLogin';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <Routes>
          <Route path="/" element={
            <>
              <HeroSection />
              <ServicesSection />
            </>
          } />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/userlogin" element={<UserLogin />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App; 