import React from 'react';
import '../styles/HeroSection.css';

const HeroSection = () => {
  return (
    <section id="hero" className="hero d-flex flex-column justify-content-center align-items-center" data-aos="fade" data-aos-delay="1500">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-6 text-center">
            <h2 className="blinking-text">Learn, Grow</h2>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection; 