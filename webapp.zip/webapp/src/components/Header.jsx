import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Header.css';

const Header = () => {
  return (
    <header id="header" className="header d-flex align-items-center fixed-top">
      <div className="container-fluid d-flex align-items-center justify-content-between">
        <Link to="/" className="logo d-flex align-items-center">
          <img src="/images/b2.jpg" alt="Learning Hub Logo" />
          <h1>Learning Hub</h1>
        </Link>
        <nav id="navbar" className="navbar">
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About</Link></li>
            <li className="dropdown">
              <Link to="#" className="active">User <i className="bi bi-chevron-down dropdown-indicator"></i></Link>
              <ul>
                <li><Link to="/signup">SignUp</Link></li>
                <li><Link to="/userlogin">Login</Link></li>
              </ul>
            </li>
            <li className="dropdown">
              <Link to="#" className="active">Browse Courses <i className="bi bi-chevron-down dropdown-indicator"></i></Link>
              <ul>
                <li className="dropdown">
                  <Link to="#">Fiction <i className="bi bi-chevron-down dropdown-indicator"></i></Link>
                  <ul>
                    <li><Link to="/userlogin" onClick={() => alert('Login To View Books')}>Crime &</Link></li>
                    <li><Link to="/userlogin" onClick={() => alert('Login To View Books')}>Adventure</Link></li>
                    <li><Link to="/userlogin" onClick={() => alert('Login To View Books')}>Humour</Link></li>
                  </ul>
                </li>
                <li className="dropdown">
                  <Link to="#">Non Fiction <i className="bi bi-chevron-down dropdown-indicator"></i></Link>
                  <ul>
                    <li><Link to="/userlogin" onClick={() => alert('Login To View Books')}>Science & History</Link></li>
                    <li><Link to="/userlogin" onClick={() => alert('Login To View Books')}>Biography & Autobiography</Link></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </nav>
        <div className="header-social-links">
          <a href="https://www.linkedin.com/pulse/online-bookstore-gaman-sai-chowdary-garapati%3FtrackingId=eRG9Ho9woRCPE0CRcGrZ2g%253D%253D/?trackingId=eRG9Ho9woRCPE0CRcGrZ2g%3D%3D" target="_blank" rel="noopener noreferrer" className="linkedin"><i className="bi bi-linkedin"></i></a>
        </div>
        <i className="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
        <i className="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
      </div>
    </header>
  );
};

export default Header; 