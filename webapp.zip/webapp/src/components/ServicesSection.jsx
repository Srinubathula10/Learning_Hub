import React from 'react';
import '../styles/ServicesSection.css';

const ServicesSection = () => {
  return (
    <section id="services" className="services">
      <div className="container">
        <div className="row gy-9">
          <div className="col-xl-5 col-md-8 d-flex">
            <div className="service-item position-relative">
              <img src="/images/jos.jpg" className="testimonial-img" alt="Fiction" />
              <h4><a href="#" className="stretched-link">Fiction</a></h4>
              <p>Fictional books are often synonymously categorized under the umbrella term of "novel." The category of fiction is immense and has a huge plethora of sub-divisions or genres, which is both a boon and a curse for bookworms.</p>
            </div>
          </div>
          <div className="col-xl-5 col-md-9 d-flex">
            <div className="service-item position-relative" style={{ marginLeft: '20px' }}>
              <img src="/images/jos1.jpg" className="testimonial-img" alt="Non-Fiction" />
              <h4><a href="#" className="stretched-link">Non-Fiction</a></h4>
              <p>The polar opposite of fictional books, nonfiction books are based on facts, true accounts of history and real events. Also, unlike fiction books, nonfiction books have relatively few genres. The most common types of books that make up nonfictional works are biographies, autobiographies, almanacs and encyclopedias.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection; 