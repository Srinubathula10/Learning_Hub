import React from 'react';
import '../styles/SignUp.css';

const SignUp = () => {
  return (
    <div className="signup-container">
      <h1>Sign Up</h1>
      <p>Create an account to access exclusive content and features.</p>
    </div>
  );
};

export default SignUp; 