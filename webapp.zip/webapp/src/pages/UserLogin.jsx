import React from 'react';
import '../styles/UserLogin.css';

const UserLogin = () => {
  return (
    <div className="userlogin-container">
      <h1>User Login</h1>
      <p>Log in to your account to access your personalized dashboard.</p>
    </div>
  );
};

export default UserLogin; 