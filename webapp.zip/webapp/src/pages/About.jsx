import React from 'react';
import '../styles/About.css';

const About = () => {
  return (
    <div className="about-container">
      <h1>About Us</h1>
      <p>Welcome to Learning Hub, your go-to platform for exploring a wide range of knowledge and educational resources.</p>
    </div>
  );
};

export default About; 